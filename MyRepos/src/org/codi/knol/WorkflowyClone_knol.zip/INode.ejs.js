var org_codi_knol_INode = function(objectId, className){
	this.objectId = objectId;
	this.className = className;
}