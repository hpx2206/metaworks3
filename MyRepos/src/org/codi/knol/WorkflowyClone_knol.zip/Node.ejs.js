var org_codi_knol_Node = function(objectId, className){
	this.objectId = objectId;
	this.className = className;
}